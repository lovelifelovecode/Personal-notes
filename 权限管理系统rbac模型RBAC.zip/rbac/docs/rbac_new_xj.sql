-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 29, 2017 at 12:14 PM
-- Server version: 5.5.56-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rbac`
--

-- --------------------------------------------------------

--
-- Table structure for table `access`
--

CREATE TABLE IF NOT EXISTS `access` (
  `id` int(11) unsigned NOT NULL,
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '权限名称',
  `urls` varchar(1000) NOT NULL DEFAULT '' COMMENT 'json 数组',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态 1：有效 0：无效',
  `updated_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '最后一次更新时间',
  `created_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '插入时间'
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='权限详情表';

--
-- Dumping data for table `access`
--

INSERT INTO `access` (`id`, `title`, `urls`, `status`, `updated_time`, `created_time`) VALUES
(1, 'page1', '["\\/index.php\\/rbac\\/index\\/page1.html"]', 1, '2017-10-29 09:10:18', '2017-10-27 03:22:47'),
(2, 'page2', '["\\/index.php\\/rbac\\/index\\/page2.html"]', 1, '2017-10-29 09:10:33', '2017-10-27 03:23:04'),
(3, 'page3', '["\\/index.php\\/rbac\\/index\\/page3.html"]', 1, '2017-10-29 09:13:52', '2017-10-27 03:23:55'),
(4, 'page4', '["\\/index.php\\/rbac\\/index\\/page4.html"]', 1, '2017-10-29 09:11:05', '2017-10-27 04:08:21'),
(5, 'page1 and page2', '["\\/index.php\\/rbac\\/index\\/page1.html\\r","\\/index.php\\/rbac\\/index\\/page2.html"]', 1, '2017-10-29 09:11:44', '2017-10-27 06:00:55'),
(6, '用户查看', '["\\/index.php\\/rbac\\/user\\/index.html"]', 1, '2017-10-29 09:22:00', '2017-10-29 09:20:44'),
(7, '用户添加', '["\\/index.php\\/rbac\\/user\\/useradd.html"]', 1, '0000-00-00 00:00:00', '2017-10-29 09:22:45');

-- --------------------------------------------------------

--
-- Table structure for table `app_access_log`
--

CREATE TABLE IF NOT EXISTS `app_access_log` (
  `id` int(11) NOT NULL,
  `uid` bigint(20) NOT NULL DEFAULT '0' COMMENT '品牌UID',
  `target_url` varchar(255) NOT NULL DEFAULT '' COMMENT '访问的url',
  `query_params` longtext NOT NULL COMMENT 'get和post参数',
  `ua` varchar(255) NOT NULL DEFAULT '' COMMENT '访问ua',
  `ip` varchar(32) NOT NULL DEFAULT '' COMMENT '访问ip',
  `note` varchar(1000) NOT NULL DEFAULT '' COMMENT 'json格式备注字段',
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=211 DEFAULT CHARSET=utf8 COMMENT='用户操作记录表';

--
-- Dumping data for table `app_access_log`
--

INSERT INTO `app_access_log` (`id`, `uid`, `target_url`, `query_params`, `ua`, `ip`, `note`, `created_time`) VALUES
(1, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:30:00'),
(2, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:30:02'),
(3, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:30:03'),
(4, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:30:04'),
(5, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:30:24'),
(6, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:30:27'),
(7, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:31:08'),
(8, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:31:24'),
(9, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:31:36'),
(10, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:31:37'),
(11, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:31:37'),
(12, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:32:02'),
(13, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:32:03'),
(14, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:32:04'),
(15, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:32:04'),
(16, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:32:04'),
(17, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:32:04'),
(18, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:32:17'),
(19, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:32:47'),
(20, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:32:47'),
(21, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:32:48'),
(22, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:32:48'),
(23, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:32:48'),
(24, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:32:48'),
(25, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:32:49'),
(26, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:33:10'),
(27, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:34:09'),
(28, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:34:36'),
(29, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:34:54'),
(30, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:34:54'),
(31, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:34:55'),
(32, 36, '/index.php/rbac/index/page3.html', '', '', '127.0.0.1', '', '2017-10-29 11:35:05'),
(33, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:35:06'),
(34, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:36:11'),
(35, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:38:46'),
(36, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:38:47'),
(37, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:38:47'),
(38, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:38:47'),
(39, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:38:48'),
(40, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:38:48'),
(41, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:38:48'),
(42, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:38:48'),
(43, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:38:48'),
(44, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:38:48'),
(45, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:38:49'),
(46, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:38:49'),
(47, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:38:49'),
(48, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:39:17'),
(49, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:39:46'),
(50, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:40:22'),
(51, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:40:24'),
(52, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:40:25'),
(53, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:40:25'),
(54, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:40:25'),
(55, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:41:01'),
(56, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:42:36'),
(57, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:43:26'),
(58, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:44:05'),
(59, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:44:17'),
(60, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:44:54'),
(61, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:45:27'),
(62, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:45:49'),
(63, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:46:09'),
(64, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:46:46'),
(65, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:48:27'),
(66, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:49:23'),
(67, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:50:13'),
(68, 7, '/index.php/rbac/operation_log/index.html?page=2', '', '', '127.0.0.1', '', '2017-10-29 11:50:15'),
(69, 7, '/index.php/rbac/operation_log/index.html?page=3', '', '', '127.0.0.1', '', '2017-10-29 11:50:16'),
(70, 7, '/index.php/rbac/operation_log/index.html?page=4', '', '', '127.0.0.1', '', '2017-10-29 11:50:17'),
(71, 7, '/index.php/rbac/operation_log/index.html?page=5', '', '', '127.0.0.1', '', '2017-10-29 11:50:18'),
(72, 7, '/index.php/rbac/operation_log/index.html?page=6', '', '', '127.0.0.1', '', '2017-10-29 11:50:18'),
(73, 7, '/index.php/rbac/operation_log/index.html?page=7', '', '', '127.0.0.1', '', '2017-10-29 11:50:19'),
(74, 7, '/index.php/rbac/operation_log/index.html?page=8', '', '', '127.0.0.1', '', '2017-10-29 11:50:20'),
(75, 7, '/index.php/rbac/operation_log/index.html?page=8', '', '', '127.0.0.1', '', '2017-10-29 11:50:33'),
(76, 7, '/index.php/rbac/operation_log/index.html?page=6', '', '', '127.0.0.1', '', '2017-10-29 11:50:35'),
(77, 7, '/index.php/rbac/operation_log/index.html?page=8', '', '', '127.0.0.1', '', '2017-10-29 11:50:36'),
(78, 7, '/index.php/rbac/operation_log/index.html?page=11', '', '', '127.0.0.1', '', '2017-10-29 11:50:37'),
(79, 7, '/index.php/rbac/operation_log/index.html?page=12', '', '', '127.0.0.1', '', '2017-10-29 11:50:38'),
(80, 7, '/index.php/rbac/operation_log/index.html?page=13', '', '', '127.0.0.1', '', '2017-10-29 11:50:39'),
(81, 7, '/index.php/rbac/operation_log/index.html?page=40', '', '', '127.0.0.1', '', '2017-10-29 11:50:41'),
(82, 7, '/index.php/rbac/operation_log/index.html?page=41', '', '', '127.0.0.1', '', '2017-10-29 11:50:42'),
(83, 7, '/index.php/rbac/operation_log/index.html?page=41', '', '', '127.0.0.1', '', '2017-10-29 11:51:14'),
(84, 7, '/index.php/rbac/operation_log/index.html?page=41', '', '', '127.0.0.1', '', '2017-10-29 11:51:15'),
(85, 7, '/index.php/rbac/operation_log/index.html?page=41', '', '', '127.0.0.1', '', '2017-10-29 11:51:15'),
(86, 7, '/index.php/rbac/operation_log/index.html?page=41', '', '', '127.0.0.1', '', '2017-10-29 11:51:15'),
(87, 7, '/index.php/rbac/operation_log/index.html?page=41', '', '', '127.0.0.1', '', '2017-10-29 11:51:15'),
(88, 7, '/index.php/rbac/operation_log/index.html?page=41', '', '', '127.0.0.1', '', '2017-10-29 11:51:15'),
(89, 7, '/index.php/rbac/operation_log/index.html?page=42', '', '', '127.0.0.1', '', '2017-10-29 11:51:16'),
(90, 7, '/index.php/rbac/operation_log/index.html?page=44', '', '', '127.0.0.1', '', '2017-10-29 11:51:17'),
(91, 7, '/index.php/rbac/operation_log/index.html?page=42', '', '', '127.0.0.1', '', '2017-10-29 11:51:17'),
(92, 7, '/index.php/rbac/operation_log/index.html?page=43', '', '', '127.0.0.1', '', '2017-10-29 11:51:18'),
(93, 7, '/index.php/rbac/operation_log/index.html?page=43', '', '', '127.0.0.1', '', '2017-10-29 11:53:48'),
(94, 7, '/index.php/rbac/operation_log/index.html?page=43', '', '', '127.0.0.1', '', '2017-10-29 11:53:49'),
(95, 7, '/index.php/rbac/operation_log/index.html?page=43', '', '', '127.0.0.1', '', '2017-10-29 11:53:49'),
(96, 7, '/index.php/rbac/operation_log/index.html?page=43', '', '', '127.0.0.1', '', '2017-10-29 11:53:49'),
(97, 7, '/index.php/rbac/operation_log/index.html?page=2', '', '', '127.0.0.1', '', '2017-10-29 11:53:50'),
(98, 7, '/index.php/rbac/operation_log/index.html?page=5', '', '', '127.0.0.1', '', '2017-10-29 11:53:51'),
(99, 7, '/index.php/rbac/operation_log/index.html?page=49', '', '', '127.0.0.1', '', '2017-10-29 11:53:52'),
(100, 7, '/index.php/rbac/operation_log/index.html?page=50', '', '', '127.0.0.1', '', '2017-10-29 11:53:53'),
(101, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 11:53:55'),
(102, 7, '/index.php/rbac/operation_log/index.html?page=8', '', '', '127.0.0.1', '', '2017-10-29 11:53:57'),
(103, 7, '/index.php/rbac/operation_log/index.html?page=51', '', '', '127.0.0.1', '', '2017-10-29 11:53:58'),
(104, 7, '/index.php/rbac/operation_log/index.html?page=50', '', '', '127.0.0.1', '', '2017-10-29 11:54:00'),
(105, 7, '/index.php/rbac/operation_log/index.html?page=48', '', '', '127.0.0.1', '', '2017-10-29 11:54:00'),
(106, 7, '/index.php/rbac/operation_log/index.html?page=51', '', '', '127.0.0.1', '', '2017-10-29 11:54:01'),
(107, 7, '/index.php/rbac/operation_log/index.html?page=53', '', '', '127.0.0.1', '', '2017-10-29 11:54:01'),
(108, 7, '/index.php/rbac/operation_log/index.html?page=50', '', '', '127.0.0.1', '', '2017-10-29 11:54:11'),
(109, 7, '/index.php/rbac/operation_log/index.html?page=48', '', '', '127.0.0.1', '', '2017-10-29 11:54:12'),
(110, 7, '/index.php/rbac/operation_log/index.html?page=45', '', '', '127.0.0.1', '', '2017-10-29 11:54:12'),
(111, 7, '/index.php/rbac/operation_log/index.html?page=2', '', '', '127.0.0.1', '', '2017-10-29 11:54:13'),
(112, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 11:54:14'),
(113, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 11:54:22'),
(114, 7, '/index.php/rbac/operation_log/index.html?page=2', '', '', '127.0.0.1', '', '2017-10-29 11:54:25'),
(115, 7, '/index.php/rbac/operation_log/index.html?page=3', '', '', '127.0.0.1', '', '2017-10-29 11:54:27'),
(116, 7, '/index.php/rbac/operation_log/index.html?page=4', '', '', '127.0.0.1', '', '2017-10-29 11:54:35'),
(117, 7, '/index.php/rbac/operation_log/index.html?page=5', '', '', '127.0.0.1', '', '2017-10-29 11:54:38'),
(118, 7, '/index.php/rbac/operation_log/index.html?page=6', '', '', '127.0.0.1', '', '2017-10-29 11:54:40'),
(119, 7, '/index.php/rbac/operation_log/index.html?page=6', '', '', '127.0.0.1', '', '2017-10-29 11:54:50'),
(120, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 11:54:52'),
(121, 7, '/index.php/rbac/operation_log/index.html?page=2', '', '', '127.0.0.1', '', '2017-10-29 11:54:57'),
(122, 7, '/index.php/rbac/operation_log/index.html?page=3', '', '', '127.0.0.1', '', '2017-10-29 11:55:00'),
(123, 7, '/index.php/rbac/index/page1.html', '', '', '127.0.0.1', '', '2017-10-29 11:55:02'),
(124, 7, '/index.php/rbac/index/page2.html', '', '', '127.0.0.1', '', '2017-10-29 11:55:02'),
(125, 7, '/index.php/rbac/index/page3.html', '', '', '127.0.0.1', '', '2017-10-29 11:55:03'),
(126, 7, '/index.php/rbac/index/page4.html', '', '', '127.0.0.1', '', '2017-10-29 11:55:04'),
(127, 7, '/index.php/rbac/index/page3.html', '', '', '127.0.0.1', '', '2017-10-29 11:55:04'),
(128, 7, '/index.php/rbac/index/page2.html', '', '', '127.0.0.1', '', '2017-10-29 11:55:04'),
(129, 7, '/index.php/rbac/index/page1.html', '', '', '127.0.0.1', '', '2017-10-29 11:55:05'),
(130, 7, '/index.php/rbac/index/page2.html', '', '', '127.0.0.1', '', '2017-10-29 11:55:06'),
(131, 7, '/index.php/rbac/index/page1.html', '', '', '127.0.0.1', '', '2017-10-29 11:55:06'),
(132, 7, '/index.php/rbac/index/page3.html', '', '', '127.0.0.1', '', '2017-10-29 11:55:07'),
(133, 7, '/index.php/rbac/index/page4.html', '', '', '127.0.0.1', '', '2017-10-29 11:55:07'),
(134, 7, '/index.php/rbac/index/page2.html', '', '', '127.0.0.1', '', '2017-10-29 11:55:08'),
(135, 7, '/index.php/rbac/index/page1.html', '', '', '127.0.0.1', '', '2017-10-29 11:55:08'),
(136, 7, '/index.php/rbac/index/page1.html', '', '', '127.0.0.1', '', '2017-10-29 11:55:10'),
(137, 7, '/index.php/rbac/index/page2.html', '', '', '127.0.0.1', '', '2017-10-29 11:55:11'),
(138, 7, '/index.php/rbac/index/page3.html', '', '', '127.0.0.1', '', '2017-10-29 11:55:11'),
(139, 7, '/index.php/rbac/index/page4.html', '', '', '127.0.0.1', '', '2017-10-29 11:55:12'),
(140, 7, '/index.php/rbac/user/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:55:13'),
(141, 7, '/index.php/rbac/role/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:55:14'),
(142, 7, '/index.php/rbac/authority/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:55:14'),
(143, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:55:15'),
(144, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:55:17'),
(145, 7, '/index.php/rbac/operation_log/index.html?page=2', '', '', '127.0.0.1', '', '2017-10-29 11:55:20'),
(146, 7, '/index.php/rbac/operation_log/index.html?page=3', '', '', '127.0.0.1', '', '2017-10-29 11:55:22'),
(147, 7, '/index.php/rbac/operation_log/index.html?page=4', '', '', '127.0.0.1', '', '2017-10-29 11:55:25'),
(148, 7, '/index.php/rbac/operation_log/index.html?page=5', '', '', '127.0.0.1', '', '2017-10-29 11:55:27'),
(149, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 11:55:40'),
(150, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 11:55:58'),
(151, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 11:56:13'),
(152, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:57:34'),
(153, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:57:55'),
(154, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:59:08'),
(155, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 11:59:39'),
(156, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 12:00:29'),
(157, 7, '/index.php/rbac/operation_log/index.html?page=6', '', '', '127.0.0.1', '', '2017-10-29 12:00:31'),
(158, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:00:34'),
(159, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:00:43'),
(160, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:01:14'),
(161, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:01:45'),
(162, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:02:28'),
(163, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:02:29'),
(164, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:02:41'),
(165, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:02:58'),
(166, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:03:55'),
(167, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:03:56'),
(168, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:03:56'),
(169, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:04:58'),
(170, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:05:31'),
(171, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:05:33'),
(172, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:06:04'),
(173, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:06:29'),
(174, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:06:30'),
(175, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:06:31'),
(176, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:06:45'),
(177, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:06:47'),
(178, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:06:48'),
(179, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:07:03'),
(180, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:07:04'),
(181, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:07:04'),
(182, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:07:05'),
(183, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:07:05'),
(184, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:07:05'),
(185, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:07:05'),
(186, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:07:48'),
(187, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:07:49'),
(188, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:07:49'),
(189, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:07:49'),
(190, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:07:49'),
(191, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:08:42'),
(192, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:09:06'),
(193, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:09:27'),
(194, 7, '/index.php/rbac/operation_log/index.html?page=1', '', '', '127.0.0.1', '', '2017-10-29 12:10:18'),
(195, 7, '/index.php/rbac/operation_log/index.html?page=3', '', '', '127.0.0.1', '', '2017-10-29 12:10:24'),
(196, 7, '/index.php/rbac/operation_log/index.html?page=4', '', '', '127.0.0.1', '', '2017-10-29 12:10:27'),
(197, 7, '/index.php/rbac/operation_log/index.html?page=4', '', '', '127.0.0.1', '', '2017-10-29 12:10:55'),
(198, 7, '/index.php/rbac/operation_log/index.html?page=4', '', '', '127.0.0.1', '', '2017-10-29 12:10:59'),
(199, 7, '/index.php/rbac/operation_log/index.html?page=4', '', '', '127.0.0.1', '', '2017-10-29 12:11:42'),
(200, 7, '/index.php/rbac/operation_log/index.html', '', '', '127.0.0.1', '', '2017-10-29 12:11:45'),
(201, 7, '/index.php/rbac/authority/index.html', '', '', '127.0.0.1', '', '2017-10-29 12:11:46'),
(202, 7, '/index.php/rbac/role/index.html', '', '', '127.0.0.1', '', '2017-10-29 12:11:46'),
(203, 7, '/index.php/rbac/user/index.html', '', '', '127.0.0.1', '', '2017-10-29 12:11:47'),
(204, 7, '/index.php/rbac/index/page4.html', '', '', '127.0.0.1', '', '2017-10-29 12:11:47'),
(205, 7, '/index.php/rbac/index/page3.html', '', '', '127.0.0.1', '', '2017-10-29 12:11:48'),
(206, 36, '/index.php/rbac/user/index.html', '', '', '127.0.0.1', '', '2017-10-29 12:11:53'),
(207, 36, '/index.php/rbac/user/index.html', '', '', '127.0.0.1', '', '2017-10-29 12:11:56'),
(208, 36, '/index.php/rbac/index/page4.html', '', '', '127.0.0.1', '', '2017-10-29 12:11:56'),
(209, 36, '/index.php/rbac/index/page3.html', '', '', '127.0.0.1', '', '2017-10-29 12:11:57'),
(210, 36, '/index.php/rbac/index/page1.html', '', '', '127.0.0.1', '', '2017-10-29 12:11:58');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE IF NOT EXISTS `role` (
  `id` int(11) unsigned NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '角色名称',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态 1：有效 0：无效',
  `updated_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '最后一次更新时间',
  `created_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '插入时间'
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='角色表';

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `name`, `status`, `updated_time`, `created_time`) VALUES
(3, '销售', 1, '0000-00-00 00:00:00', '2017-10-25 08:36:40'),
(4, '运营', 1, '0000-00-00 00:00:00', '2017-10-25 08:39:39'),
(5, '设计', 1, '0000-00-00 00:00:00', '2017-10-25 08:44:51');

-- --------------------------------------------------------

--
-- Table structure for table `role_access`
--

CREATE TABLE IF NOT EXISTS `role_access` (
  `id` int(11) unsigned NOT NULL,
  `role_id` int(11) NOT NULL DEFAULT '0' COMMENT '角色id',
  `access_id` int(11) NOT NULL DEFAULT '0' COMMENT '权限id',
  `created_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '插入时间'
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8 COMMENT='角色权限表';

--
-- Dumping data for table `role_access`
--

INSERT INTO `role_access` (`id`, `role_id`, `access_id`, `created_time`) VALUES
(114, 5, 4, '2017-10-29 09:15:16'),
(115, 5, 3, '2017-10-29 09:15:35'),
(116, 5, 4, '2017-10-29 09:15:35'),
(117, 4, 1, '2017-10-29 09:15:56'),
(118, 5, 3, '2017-10-29 09:20:55'),
(119, 5, 4, '2017-10-29 09:20:55'),
(120, 5, 6, '2017-10-29 09:20:55'),
(121, 5, 3, '2017-10-29 09:23:03'),
(122, 5, 4, '2017-10-29 09:23:03'),
(123, 5, 6, '2017-10-29 09:23:03'),
(124, 5, 7, '2017-10-29 09:23:03');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) unsigned NOT NULL,
  `username` varchar(20) NOT NULL DEFAULT '' COMMENT '姓名',
  `password` varchar(32) NOT NULL DEFAULT '' COMMENT '姓名',
  `email` varchar(30) NOT NULL DEFAULT '' COMMENT '邮箱',
  `is_admin` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否是超级管理员 1表示是 0 表示不是',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态 1：有效 0：无效',
  `updated_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '最后一次更新时间',
  `created_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '插入时间'
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8 COMMENT='用户表';

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `email`, `is_admin`, `status`, `updated_time`, `created_time`) VALUES
(7, 'xiaojing', '1b201129199e4c6bf86e297e5e9ca6bd', '123@qq.com', 1, 1, '2017-10-29 08:03:38', '0000-00-00 00:00:00'),
(36, 'king', '0abdc646042a4684544ee2b258842a1c', '', 0, 1, '2017-10-29 09:16:05', '2017-10-26 10:05:39'),
(37, 'jing', '5eaceeeba8bb8d23a7374a08e401b116', '', 0, 1, '2017-10-26 10:19:35', '2017-10-26 10:19:05'),
(40, '花样百出', '287a37a47a53ad16b70590a9f6fc98a8', '', 0, 1, '0000-00-00 00:00:00', '2017-10-28 10:47:11'),
(41, '草木灰', '9a2e832b2910047fa05c1e469b8d02e5', '', 0, 1, '0000-00-00 00:00:00', '2017-10-28 10:48:58'),
(42, 'haining', '18ea5342657d5fbe54acf99d12ec4471', '', 0, 1, '0000-00-00 00:00:00', '2017-10-29 09:23:27'),
(43, '222', '9932d79c21e40cd0834e8644a999ac33', '', 0, 1, '0000-00-00 00:00:00', '2017-10-29 09:24:03');

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE IF NOT EXISTS `user_role` (
  `id` int(11) unsigned NOT NULL,
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `role_id` int(11) NOT NULL DEFAULT '0' COMMENT '角色ID',
  `created_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '插入时间'
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8 COMMENT='用户角色表';

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`id`, `uid`, `role_id`, `created_time`) VALUES
(5, 1, 44, '2017-10-24 00:34:35'),
(55, 36, 5, '2017-10-29 09:14:58'),
(56, 36, 4, '2017-10-29 09:16:05'),
(57, 42, 3, '2017-10-29 09:23:27'),
(58, 42, 4, '2017-10-29 09:23:27'),
(59, 43, 4, '2017-10-29 09:24:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `access`
--
ALTER TABLE `access`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_access_log`
--
ALTER TABLE `app_access_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_uid` (`uid`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_access`
--
ALTER TABLE `role_access`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_role_id` (`role_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_email` (`email`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_uid` (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `access`
--
ALTER TABLE `access`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `app_access_log`
--
ALTER TABLE `app_access_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=211;
--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `role_access`
--
ALTER TABLE `role_access`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=125;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=60;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
