<?php
namespace app\common\model;
use think\Model;
use think\Db;
/**
* 角色与权限的关系模型
*/
class OperationLog extends Model
{
	protected $pk = 'id';
	protected $table = 'app_access_log';
	protected $insert = ['created_time'];

	protected function setCreatedTimeAttr($value){
		return date("Y-m-d H:i:s");
	}

	public function operationList(){
		$result = Db::table('app_access_log')->alias('a')->join('__USER__ u','a.uid=u.id','LEFT')
			->field( 'a.target_url,a.query_params,a.ip,a.created_time,u.username' )
			->paginate(50);

		$replace =[
			'page1',
			'page2',
			'page3',
			'page4',
			'用户查看',
			'用户添加',
			'用户操作日志列表'
		];
		$search  = [
			'/index.php/rbac/index/page1.html',
			'/index.php/rbac/index/page2.html',
			'/index.php/rbac/index/page3.html',
			'/index.php/rbac/index/page4.html',
			'/index.php/rbac/user/index.html',
			'/index.php/rbac/user/useradd.html',
			'/index.php/rbac/operation_log/index.html',
		];

		foreach ($result as $key => &$value) {
			// dump($value['target_url']);
			$value['target_url'] = str_replace($search, $replace, $value['target_url']);
		}
		return $result;
	}
}