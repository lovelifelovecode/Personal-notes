<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:63:"/var/www/rbac/public/../application/rbac/view/user/useradd.html";i:1509008470;s:55:"/var/www/rbac/public/../application/rbac/view/base.html";i:1509269211;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
    <title>Bootstrap 101 Template</title>

    <!-- Bootstrap -->
    <link href="__STATIC__/rbac/css/bootstrap.min.css" rel="stylesheet">
    <link href="__STATIC__/rbac/css/dashboard.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://cdn.bootcss.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
<!--nav-->
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <a class="navbar-brand" href="#">RBAC</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse">
      <ul class="nav navbar-nav">
        <li class="active"><a href="<?php echo url('index'); ?>">Home<span class="sr-only">(current)</span></a></li>
      </ul>
      <p class="navbar-text navbar-right">Hi,<?php echo session('user.user_name'); ?></p>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<!--nav-->

<!--title and content-->
<div class="container-fluid">
	<div class="col-sm-2 col-md-2 col-lg-2 sidebar">
	  <ul class="nav nav-sidebar">
	    <li>权限演示页面</li>
	    <li><a href="<?php echo url('rbac/index/page1'); ?>">test page1</a></li>
	    <li><a href="<?php echo url('rbac/index/page2'); ?>">test page2</a></li>
	    <li><a href="<?php echo url('rbac/index/page3'); ?>">test page3</a></li>
	    <li><a href="<?php echo url('rbac/index/page4'); ?>">test page4</a></li>


	    <li>系统设置</li>
	    <li><a href="<?php echo url('rbac/user/index'); ?>">用户管理</a></li>
	    <li><a href="<?php echo url('rbac/role/index'); ?>">角色管理</a></li>
	    <li><a href="<?php echo url('rbac/authority/index'); ?>">权限管理</a></li>

      <li>操作日志</li>
      <li><a href="<?php echo url('rbac/OperationLog/index'); ?>">用户操作日志</a></li>
	  </ul>
	</div>
	<div class="col-sm-10 col-sm-offset-2 col-md-10 col-md-offset-2 col-lg-10 col-lg-offset-2">

  
<div class="row">
	<div class="col-xs-9 col-sm-9 col-md-9  col-lg-9">

    <?php if(input('param.user_id')): ?>
    <h5>用户编辑</h5>
    <?php else: ?>
    <h5>新增用户</h5>
    <?php endif; ?>

	</div>
</div>
<hr/>
<form method="post">
<div class="row">
	<div class="form-horizontal user_set_wrap" role="form">
		<div class="form-group">
			<label class="col-xs-2 col-sm-2 col-md-2 col-lg-2 control-label">姓名</label>
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
				<input type="text" class="form-control" name="username" placeholder="请输入姓名" value="<?php echo $oldRoleData['username']; ?>">
			</div>
		</div>
		<div class="form-group">
			<label class="col-xs-2 col-sm-2 col-md-2 col-lg-2 control-label" >password</label>
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
				<input type="password" class="form-control" name="password" placeholder="请输入password" value="<?php echo $oldRoleData['password']; ?>">
			</div>
		</div>
        
        <!--所属角色-->
        <div class="form-group">
            <label class="col-xs-2 col-sm-2 col-md-2 col-lg-2 control-label" >所属角色</label>
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <div class="checkbox">
                    <?php if(is_array($roleList) || $roleList instanceof \think\Collection || $roleList instanceof \think\Paginator): if( count($roleList)==0 ) : echo "" ;else: foreach($roleList as $key=>$vo): ?>
                    <label>
                        <input type="checkbox" name="role_ids[]" value="<?php echo $vo['id']; ?>"
<?php if(isset($oldSelectData)): if(is_array($oldSelectData) || $oldSelectData instanceof \think\Collection || $oldSelectData instanceof \think\Paginator): if( count($oldSelectData)==0 ) : echo "" ;else: foreach($oldSelectData as $key=>$ko): if($ko['role_id'] === $vo['id']): ?>
			checked
		<?php endif; endforeach; endif; else: echo "" ;endif; endif; ?>
                        />
						<?php echo $vo['name']; ?>
                    </label>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </div>
            </div>
        </div>
        
		<div class="col-xs-6 col-xs-offset-2 col-sm-6 col-sm-offset-2 col-md-6  col-md-offset-2 col-lg-6 col-sm-lg-2 ">
          	<input type="hidden" name="user_id" value="<?php echo input('param.user_id'); ?>"> 
			<button type="sublime" class="btn btn-primary pull-right  save">确定</button>
		</div>
	</div>
</div>
</form>


		<hr>
		<footer>
			<p class="pull-left">@king</p>
			<p class="pull-right">Power by skyuse.com</p>
		</footer>
	</div>
</div>
<!--title and content-->
  </body>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="__STATIC__/rbac/js/jquery1.12.4.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="__STATIC__/rbac/js/bootstrap.min.js"></script>
</html>