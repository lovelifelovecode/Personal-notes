<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:62:"/var/www/rbac/public/../application/rbac/view/login/index.html";i:1508842109;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
    <title>Bootstrap 101 Template</title>

    <!-- Bootstrap -->
    <link href="__STATIC__/rbac/css/bootstrap.min.css" rel="stylesheet">
    <link href="__STATIC__/rbac/css/signin.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://cdn.bootcss.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
	    <div class="container">

	      <form class="form-signin" method="post">
	        <h2 class="form-signin-heading">Please sign in</h2>
	        <label for="inputEmail" class="sr-only">username</label>
	        <input type="text" name="username" id="inputEmail" class="form-control" placeholder="Username" autofocus>
	        <label for="inputPassword" class="sr-only">Password</label>
	        <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password" >
	        <div class="checkbox">
	          <label>
	            <input type="checkbox" value="remember-me"> Remember me
	          </label>
	        </div>
	        <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
	      </form>

	    </div> <!-- /container -->
  </body>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="__STATIC__/rbac/js/jquery1.12.4.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="__STATIC__/rbac/js/bootstrap.min.js"></script>
</html>