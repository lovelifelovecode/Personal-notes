<?php
    //设置utf-8的字符集
    header("Content-Type:text/html; charset=utf-8");
    //设置时区
    date_default_timezone_set("PRC");
    //设置域名网址
    $serverUrl="http://192.168.2.10:8017/admin/";
    //报告所有错误
    error_reporting(E_ALL);    
    include "db.inc.php";
