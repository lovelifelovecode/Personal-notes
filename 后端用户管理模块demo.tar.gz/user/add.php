<html>
<head>
    <title>添加用户</title>
</head>
<body>
    <?php 
        include "header.php"; 
        include "../classes/fileupload.class.php";
        include "../classes/image.class.php";
        if(isset($_POST['addUser'])){
            $savepath="../upfile/images";
            $up=new fileupload;
            $up->set("path",$savepath);
            $up->set("maxsize",2000000);
            $up->set("allowtype",array("gif","png","jpg","jpeg"));
            if($up->upload("pic")){
                $pic=$up->getFileName();
                $img=new Image($savepath);
                $img->thumb($pic,100,100,"100_100_");
            }else{
                print_r($up->getErrorMsg());
                exit;
            }
            $pic=$serverUrl.substr($savepath,3).'/'.$pic;
            $name=$_POST['user'];
            $age=$_POST['age'];
            $sql="insert into user(name,age,pic)values(?,?,?)";
            $result = $pdo->prepare($sql);
            $result->execute(array($name,$age,$pic)); 
            if($pdo->lastInsertID()){
                echo "<script>alert('用户添加成功');</script>"; 
            }else{
                echo "<script>alert('用户添加失败');</script>";
            }
        }
    ?>
    <p style="text-align:center">添加用户</p>
    <form action="" method="post" enctype="multipart/form-data">
        名字：<input type="text" name="user" value="" /><br><br>
        年龄：<input type="number" name="age" value="" /><br><br>
              <input type="hidden" mane="MAX_FILE_SIZE" value="10000000" >
        头像：<input type="file" name="pic" value="" /><br><br>
        <input type="submit" name="addUser" value="提交" />
    </form>
</body>
</html>
