<?php
    include "../public/config.inc.php";
?>
<span style="color:green; font-size:18px;">用户管理: </span>
<a href="add.php">添加用户</a>&nbsp;&nbsp;
<a href="list.php">用户列表</a>&nbsp;&nbsp;
<a href="search.php">搜索用户</a>&nbsp;&nbsp;
