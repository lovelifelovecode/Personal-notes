<html>
<head>
    <title>修改用户</title>
</head>
<body>
    <?php 
        include "header.php"; 
        include "../classes/fileupload.class.php";
        include "../classes/image.class.php";
if(isset($_POST['eddUser'])){

    //判断是否有图片修改
    if($_FILES['pic']['error']==0){
        $savepath="../upfile/images";
        $up=new fileupload;
        $up->set("path",$savepath);
        $up->set("maxsize",2000000);
        $up->set("allowtype",array("gif","png","jpg","jpeg"));
        if($up->upload("pic")){
            //删除旧图片
            $old_pic=basename($_POST['old_pic']);
            @unlink('../upfile/images/'.$old_pic);
            @unlink('../upfile/images/100_100_'.$old_pic);
            $pic=$up->getFileName();
            $img=new Image($savepath);
            $img->thumb($pic,100,100,"100_100_");
        }else{
            print_r($up->getErrorMsg());
            exit;
        }
        $pic=$serverUrl.substr($savepath,3).'/'.$pic;
        $id=$_POST['id'];
        $user=$_POST['user'];
        $age=$_POST['age'];
        $result=$pdo->prepare("update user set name=? , age=? ,pic=? where id=?");
        $result->execute(array($user,$age,$pic,$id));
        if($result->rowCount()){
            echo "<script>alert('修改成功！');</script>";
            echo "<script>window.location.href='list.php';</script>";
            exit;
        }else{
            echo "<script>alert('修改失败！或没有修改数据');</script>";
        }
    }

    $id=$_POST['id'];
    $user=$_POST['user'];
    $age=$_POST['age'];
    $result=$pdo->prepare("update user set name=? , age=? where id=?");
    $result->execute(array($user,$age,$id));
    if($result->rowCount()){
        echo "<script>alert('修改成功！');</script>";
        echo "<script>window.location.href='list.php';</script>";
        exit;
    }else{
        echo "<script>alert('修改失败！或没有修改数据');</script>";
    }
}

        $id=$_GET['id'];
        $result = $pdo->prepare("select name,age,pic from user where id=?");
        $result->execute(array($id));
        list($name,$age,$pic)= $result->fetch(PDO::FETCH_NUM);
        $html=<<<"EOT"
    <p style="text-align:center">修改用户</p>
    <form action="" method="post" enctype="multipart/form-data">
              <input type="hidden" name="id" value="{$id}" /><br>
        名字：<input type="text" name="user" value="{$name}" /><br><br>
        年龄：<input type="number" name="age" value="{$age}" /><br><br>
        <img style="max-width:50px; max-height:50px;" src="{$pic}" /><br><br>
        <input type="hidden" mane="MAX_FILE_SIZE" value="10000000" >
        <input type="hidden" name="old_pic" value="{$pic}" />
        头像：<input type="file" name="pic" value="" /><br><br>
        <input type="submit" name="eddUser" value="提交" />
    </form>
EOT;
        echo $html;
    ?>
    
</body>
</html>
