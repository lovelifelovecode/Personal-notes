<?php
class ConnectDB{
    private function __construct($name,$age){
    }
    static function setConnect($dbhost,$dbname,$dbuser,$dbpassword,$charset){
        $obj = new PDO("mysql:host=$dbhost; dbname=$dbname","$dbuser","$dbpassword");
        return $obj;
    }
    public function __destruct(){
        echo 'This is One Class.<br>';
    }
}

$pdo = ConnectDB::setConnect("localhost","skyuseapp","root","","utf-8");
$pdo->query("set names utf8");
$pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
