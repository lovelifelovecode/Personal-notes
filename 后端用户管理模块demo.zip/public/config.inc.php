<?php
    //设置utf-8的字符集
    header("Content-Type:text/html; charset=utf-8");
    //设置时区
    date_default_timezone_set("PRC");
    //设置域名网址
    $serverUrl="http://192.168.2.10:8017/admin/";
    include "db.inc.php";
