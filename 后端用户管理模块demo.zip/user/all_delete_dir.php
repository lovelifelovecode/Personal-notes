<?php
function deldir($path){
    $dh = opendir($path);
    //var_dump(readdir($dh));
    while(($d = readdir($dh)) !== false){
        if($d == '.' || $d == '..'){//如果为.或..
            continue;
        }
        $tmp = $path.'/'.$d;
        if(!is_dir($tmp)){//如果为文件
            unlink($tmp);
        }else{//如果为目录
            deldir($tmp);
        }
    }
    closedir($dh);
    rmdir($path); 
}
$path = "skyuseideal";
deldir($path);
?>
