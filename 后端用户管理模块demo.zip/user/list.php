<html>
<head>
    <title>用户列表</title>
</head>
<body>
    <?php
        include "header.php";
        //列表页点击删除
        if(isset($_GET['action'])){
            if($_GET['action']=='delete'){
                $id=$_GET['id'];


                //删除文件夹中的图片
                $home=$pdo->prepare("select pic from user where id=?");
                $home->execute(array($id));
                while(list($pic)=($home->fetch(PDO::FETCH_NUM))){
                    $picname=basename($pic);
                    @unlink('../upfile/images/'.$picname);
                    @unlink('../upfile/images/100_100_'.$picname);
                    var_dump($picname);
                }

                $result=$pdo->prepare("delete from user where id=?");
                $result->execute(array($id));
                if($result->rowCount()){
                    echo "<script>alert('删除成功！');window.location.href='list.php';</script>";
                }else{
                    echo "<script>alert('删除失败！');</script>";
                }
            }
        }

        //列表页选中删除
        if(isset($_POST['allDelete'])){
            print_r($_POST);
            //删除文件夹下的图片
            foreach($_POST['id'] as $home){
                $result=$pdo->prepare("select pic from user where id=?");
                $result->execute(array($home));
                while(list($pic)=$result->fetch(PDO::FETCH_NUM)){
                    $picname=basename($pic);
                    @unlink('../upfile/images/'.$picname);
                    @unlink('../upfile/images/100_100_'.$picname);
                }
            }
            


            $sql="delete from user where id in(".implode(',',$_POST['id']).")";
            $result=$pdo->prepare($sql);
            $result->execute();
            if($result->rowCount()){
                //echo "<script>alert('删除成功！');window.location.href='list.php';</script>";
            }else{
                echo "<script>alert('删除失败！');</script>";
            }
        }

        $sql="select id,name,age from user";
        $result = $pdo->prepare($sql);
        $result->execute();
        //print_r($result->fetchAll(PDO::FETCH_ASSOC));
        echo '<form action="list.php" method="post">';
        echo '<table border="1">';
        echo '<tr><th>选择</th><th>姓名</th><th>年龄</th><th>操作</th></tr>';
        while(list($id,$name,$age)=($result->fetch(PDO::FETCH_NUM))){
            $html=<<<"EOT"
    <tr>
        <td><input type="checkbox" name="id[]" value="{$id}" > </td>
        <td>{$name}</td>
        <td>{$age}</td>
        <td>
            <a href="edit.php?id={$id}">修改</a>/
            <a onclick="return confirm('您确定要删除《 {$name} 》这条数据吗？')" href="list.php?action=delete&id={$id}">删除</a>
    </tr>
EOT;
            echo $html;
        }

        echo '<tr><td><input onclick="return confirm(\'您确定删除这些数据吗？\');" type="submit" name="allDelete" value="删除" /></td><td colspan="3">分页</td><tr>';
        echo '</table>';
        echo '<form>';
    ?>        
</body>
</html>
