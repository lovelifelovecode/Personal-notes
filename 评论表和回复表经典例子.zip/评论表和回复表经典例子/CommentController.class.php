<?php
// 本类由系统自动生成，仅供测试用途
namespace Home\Controller;
use Think\Controller;
header("content-type:text/html; charset=utf-8");
class IndexController extends Controller {
    public function index(){
    	$articleid=2;
    	$article = M('article');
		$comment = M("comment");
		$reply = M("reply");
		$user = M("user");

		$data['article'] = $article->where("article_id=$articleid")->find();

		$data['comment'] = $comment
			->join('LEFT JOIN user ON comment.comment_userid = user.user_id')
			->where("comment.comment_typeid=$articleid")
			->select();

		foreach($data['comment'] as $key=>$value){
			$comment_id = $value['comment_id'];
			$data['comment'][$key]['reply'] = $reply
				->join("LEFT JOIN user ON reply.reply_userid = user.user_id")
				->where("reply_commentid = $comment_id")
				->select();


			foreach($data['comment'][$key]['reply'] as $k=>&$v){
				$reply_type = $v['reply_type'];
				$reply_touserid = $v['reply_touserid'];
				if($reply_type == "reply"){
					$reply_typeid = $v['reply_typeid'];
					$reply_info = $reply->where("reply_id=$reply_typeid")->find();
					$user_info = $user->where("user_id=$reply_touserid")->find();
					$v['reply_touserid'] = '@'.$user_info['user_name'].'>>PhpSKyUsePhp<<'.$reply_info['reply_content'];
				}
			}

		}
		$this->ajaxReturn($data);
		// echo "<pre>";
		// var_dump($data);
		// echo "</pre>";
    }
}